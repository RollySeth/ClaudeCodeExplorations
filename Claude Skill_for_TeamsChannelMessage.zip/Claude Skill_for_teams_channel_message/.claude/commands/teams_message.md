# /teams_message - Send Teams Channel Message

Send a message to a Microsoft Teams channel via email-to-channel.

## Usage

```
/teams_message <message> | [subject] | [channel]
```

## Arguments

- **Message** (required): The message content to send
- **Subject** (optional): Email subject line (default: "Claude Code Notification")
- **Channel** (optional): Channel key from config.json (default: configured default)

## Examples

```
/teams_message Build completed successfully!
/teams_message Build completed! | CI/CD Alert
/teams_message Critical error detected | Alert | ops
```

## Instructions

1. **Parse Arguments** (separated by `|`):
   - First: Message content (required)
   - Second: Subject line (optional)
   - Third: Channel key (optional)

2. **Load Configuration**:
   - Read `scripts/config.json` for channel email addresses
   - Use default channel if not specified

3. **Validate Channel**:
   - Check if channel key exists in config
   - Fall back to default if not found
   - Error if no valid channel

4. **Execute PowerShell Script**:
   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File "scripts/send_teams_message.ps1" -Message "<message>" -Subject "<subject>" -Channel "<channel>"
   ```

5. **Confirm Success**:
   - Display confirmation with channel name
   - Show any errors if send failed

## Output Format

```
✅ Message sent to Teams!

📍 Channel: Dev Team
📧 Subject: CI/CD Alert
💬 Message: Build completed successfully!
```

## Error Handling

- If Outlook not available: Prompt user to open Outlook
- If channel not found: List available channels from config
- If send fails: Show error and suggest checking Outlook

## Time Saved

~2 minutes per message (opening Teams, navigating, typing)
