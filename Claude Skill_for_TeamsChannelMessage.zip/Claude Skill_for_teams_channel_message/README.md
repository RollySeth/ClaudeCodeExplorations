# Teams Message Skill for Claude Code

Send messages to Microsoft Teams channels directly from Claude Code using the email-to-channel method.

---

## Why Email-to-Channel?

Many organizations have DLP (Data Loss Prevention) policies that block:
- Microsoft Graph API chat permissions
- Power Automate HTTP triggers
- Teams Incoming Webhooks

**The email-to-channel method** sends an email to the channel's unique email address, which Teams converts to a channel message.

---

## Features

- **DLP-Friendly** - Works even with strict security policies
- **No API Setup** - Uses Outlook, no tokens or app registrations needed
- **Simple Integration** - One command to send messages
- **Claude Code Native** - Seamless terminal workflow
- **Customizable** - Configure multiple channels

---

## Prerequisites

1. **Microsoft Outlook** (desktop application) installed and configured
2. **Teams Channel** with email posting enabled
3. **PowerShell 5.1+**

---

## Setup

### Step 1: Get Your Teams Channel Email Address

1. Open **Microsoft Teams**
2. Navigate to your target channel
3. Click the **three dots (...)** next to the channel name
4. Select **Get email address**
5. Copy the email address (format: `xxxxxxxx.domain.com@region.teams.ms`)

> **Note:** If you don't see "Get email address", your admin may have disabled this feature. Contact your IT admin.

### Step 2: Configure the Skill

Edit `scripts/config.json`:

```json
{
  "defaultChannel": "notifications",
  "channels": {
    "notifications": {
      "name": "Notifications Channel",
      "email": "your-channel-id.yourcompany.com@amer.teams.ms",
      "description": "General notifications from Claude Code"
    },
    "alerts": {
      "name": "Alerts Channel",
      "email": "another-channel-id.yourcompany.com@amer.teams.ms",
      "description": "Critical alerts and warnings"
    }
  },
  "defaultSubject": "Claude Code Notification",
  "senderName": "Claude Code"
}
```

### Step 3: Install the Skill

Copy the files to your project:

```
your-project/
├── .claude/
│   └── commands/
│       └── teams_message.md    # Skill definition
├── scripts/
│   ├── send_teams_message.ps1  # PowerShell script
│   └── config.json             # Your channel configuration
└── README.md
```

### Step 4: Test the Skill

```
/teams_message Hello from Claude Code!
```

---

## Usage

### Basic Message

```
/teams_message Build completed successfully!
```

### Message with Subject

```
/teams_message Build completed successfully! | CI/CD Alert
```

### Message to Specific Channel

```
/teams_message Critical error in production | Alert | alerts
```

### Natural Language

You can also ask Claude naturally:

```
Hey Claude, send a message to Teams saying the deployment finished
```

---

## Command Format

```
/teams_message <message> | [subject] | [channel]
```

| Argument | Required | Default | Description |
|----------|----------|---------|-------------|
| message | Yes | - | The message content |
| subject | No | "Claude Code Notification" | Email subject (shows as message header) |
| channel | No | "notifications" | Channel key from config.json |

---

## Configuration Options

### config.json Reference

```json
{
  "defaultChannel": "notifications",
  "channels": {
    "<channel-key>": {
      "name": "Display Name",
      "email": "channel-email@region.teams.ms",
      "description": "What this channel is for"
    }
  },
  "defaultSubject": "Claude Code Notification",
  "senderName": "Claude Code",
  "enableHtmlFormatting": true,
  "includeTimestamp": true
}
```

### Multiple Channels Example

```json
{
  "defaultChannel": "dev",
  "channels": {
    "dev": {
      "name": "Dev Team",
      "email": "dev-channel.company.com@amer.teams.ms",
      "description": "Development updates"
    },
    "ops": {
      "name": "Operations",
      "email": "ops-channel.company.com@amer.teams.ms",
      "description": "Ops alerts"
    },
    "general": {
      "name": "General",
      "email": "general.company.com@amer.teams.ms",
      "description": "General announcements"
    }
  }
}
```

---

## Message Formatting

Teams supports basic HTML in email messages:

```
/teams_message <b>Build Status:</b> SUCCESS<br><br>Branch: main<br>Commit: abc123 | Build Report
```

Supported tags:
- `<b>`, `<strong>` - Bold
- `<i>`, `<em>` - Italic
- `<br>` - Line break
- `<a href="url">text</a>` - Links
- `<ul>`, `<li>` - Lists

---

## Example Workflows

### After Running Tests

```
/teams_message All 47 tests passed! Ready for code review. | Test Results
```

### Build Notifications

```
/teams_message <b>Build #123</b><br>Status: SUCCESS<br>Duration: 3m 42s | Build Complete
```

### Deployment Alerts

```
/teams_message Production deployment completed for v2.1.0 | Deployment | ops
```

### Daily Standup Reminder

```
/teams_message Standup in 15 minutes! | Reminder | dev
```

---

## Troubleshooting

### "Cannot create Outlook object"

**Cause:** Outlook not installed or not configured.

**Fix:** Install Microsoft Outlook desktop app and set up your email account.

### "Channel email not found"

**Cause:** The channel key doesn't exist in config.json.

**Fix:** Check your config.json and use a valid channel key, or update the config.

### "Get email address" option not available in Teams

**Cause:** Your organization has disabled email-to-channel.

**Fix:** Contact your IT admin to enable "Allow members to send emails to a channel email address" in Teams admin settings.

### Message not appearing in Teams

**Causes:**
1. Email may be in channel's spam/moderation queue
2. Channel email address is incorrect
3. Outlook failed to send

**Fixes:**
1. Check Teams channel settings for moderation
2. Verify the email address in config.json
3. Check Outlook's Sent Items folder

### PowerShell Execution Policy Error

**Fix:**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## Security Notes

- Messages are sent through your Outlook account
- Your email address appears as the sender in Teams
- No credentials stored in scripts (uses Outlook COM)
- Channel email addresses should be treated as semi-sensitive

---

## File Structure

```
teams_message_public/
├── .claude/
│   └── commands/
│       └── teams_message.md      # Claude Code skill definition
├── scripts/
│   ├── send_teams_message.ps1    # PowerShell send script
│   └── config.sample.json        # Sample configuration
└── README.md                     # This file
```

---

## Integration with Other Skills

Combine with other Claude Code skills:

```
# After filing a bug
/newbug Login broken | Auth fails on mobile
/teams_message Filed bug #12345 for login issue | Bug Filed

# After completing a task
/teams_message Finished refactoring auth module. PR ready for review. | Update
```

---

## Time Saved

~2 minutes per message (opening Teams, navigating to channel, typing message)

---

## License

MIT License - Free to use, modify, and distribute.

---

## Contributing

Feel free to submit issues and pull requests to improve this skill.

---

**Happy messaging!** 💬
