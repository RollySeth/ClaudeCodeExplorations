<#
.SYNOPSIS
    Sends a message to a Microsoft Teams channel via email.

.DESCRIPTION
    This script sends messages to Teams channels using the email-to-channel feature.
    This method bypasses DLP restrictions that block Graph API, webhooks, and Power Automate.
    Designed to work with the /teams_message Claude Code skill.

.PARAMETER Message
    The message content to send (required)

.PARAMETER Subject
    The email subject line (optional, default from config)

.PARAMETER Channel
    The channel key from config.json (optional, default from config)

.EXAMPLE
    .\send_teams_message.ps1 -Message "Build completed!"

.EXAMPLE
    .\send_teams_message.ps1 -Message "Deployment done" -Subject "Deploy Alert" -Channel "ops"

.NOTES
    Requires:
    - Microsoft Outlook desktop application
    - Teams channel with email posting enabled
    - config.json with channel email addresses
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$Message,

    [Parameter(Mandatory=$false)]
    [string]$Subject = "",

    [Parameter(Mandatory=$false)]
    [string]$Channel = ""
)

# ============================================
# CONFIGURATION
# ============================================

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath = Join-Path $scriptDir "config.json"

# Check if config exists
if (-not (Test-Path $configPath)) {
    Write-Host "ERROR: Configuration file not found: $configPath" -ForegroundColor Red
    Write-Host "Copy config.sample.json to config.json and update with your channel email addresses." -ForegroundColor Yellow
    @{
        success = $false
        error = "Configuration file not found. See README.md for setup instructions."
    } | ConvertTo-Json
    exit 1
}

# Load configuration
try {
    $config = Get-Content $configPath -Raw | ConvertFrom-Json
} catch {
    Write-Host "ERROR: Failed to parse config.json: $_" -ForegroundColor Red
    @{
        success = $false
        error = "Invalid config.json format"
    } | ConvertTo-Json
    exit 1
}

# ============================================
# RESOLVE CHANNEL
# ============================================

# Use default channel if not specified
if (-not $Channel) {
    $Channel = $config.defaultChannel
}

# Get channel configuration
$channelConfig = $config.channels.$Channel

if (-not $channelConfig) {
    Write-Host "ERROR: Channel '$Channel' not found in config.json" -ForegroundColor Red
    Write-Host "Available channels:" -ForegroundColor Yellow
    $config.channels.PSObject.Properties | ForEach-Object {
        Write-Host "  - $($_.Name): $($_.Value.name)" -ForegroundColor Gray
    }
    @{
        success = $false
        error = "Channel '$Channel' not found"
        availableChannels = @($config.channels.PSObject.Properties.Name)
    } | ConvertTo-Json
    exit 1
}

$channelEmail = $channelConfig.email
$channelName = $channelConfig.name

# Use default subject if not specified
if (-not $Subject) {
    $Subject = $config.defaultSubject
    if (-not $Subject) {
        $Subject = "Claude Code Notification"
    }
}

# ============================================
# FORMAT MESSAGE
# ============================================

$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

# Build HTML body
$htmlBody = @"
<html>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 16px;">
    <div style="background: #f5f5f5; border-left: 4px solid #6264a7; padding: 12px 16px; border-radius: 4px;">
        <div style="color: #242424; font-size: 14px; line-height: 1.5;">
            $Message
        </div>
    </div>
    <div style="margin-top: 12px; color: #616161; font-size: 11px;">
        Sent via Claude Code at $timestamp
    </div>
</body>
</html>
"@

# ============================================
# SEND VIA OUTLOOK
# ============================================

Write-Host "Sending message to Teams..." -ForegroundColor Yellow
Write-Host "  Channel: $channelName" -ForegroundColor Gray
Write-Host "  Subject: $Subject" -ForegroundColor Gray

try {
    # Create Outlook COM object
    $outlook = New-Object -ComObject Outlook.Application
    $mail = $outlook.CreateItem(0)

    # Configure email
    $mail.To = $channelEmail
    $mail.Subject = $Subject
    $mail.HTMLBody = $htmlBody

    # Send
    $mail.Send()

    # Release COM object
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($outlook) | Out-Null

    Write-Host ""
    Write-Host "Message sent successfully!" -ForegroundColor Green

    # Output JSON result
    @{
        success = $true
        channel = $channelName
        channelKey = $Channel
        subject = $Subject
        timestamp = $timestamp
        message = $Message
    } | ConvertTo-Json

} catch {
    Write-Host "ERROR: Failed to send message: $_" -ForegroundColor Red

    @{
        success = $false
        error = $_.Exception.Message
        channel = $channelName
    } | ConvertTo-Json
    exit 1
}
