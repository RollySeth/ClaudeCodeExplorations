# /kusto_report - Kusto Analytics & Email Report

Run Kusto queries, analyze data, and send formatted email reports.

## Usage

```
/kusto_report <action> | [options]
```

## Actions

| Action | Description | Example |
|--------|-------------|---------|
| `query` | Run a KQL query | `/kusto_report query \| daily_summary` |
| `report` | Generate HTML report | `/kusto_report report` |
| `send` | Generate and email report | `/kusto_report send` |
| `status` | Check Kusto connection | `/kusto_report status` |

## Examples

```
/kusto_report status
/kusto_report query | SELECT * FROM Events | take 10
/kusto_report report | daily_summary
/kusto_report send | weekly_metrics
```

## Instructions

### For `status` action:

1. Check Azure CLI authentication:
   ```powershell
   az account show
   ```

2. Test Kusto cluster access:
   ```powershell
   $config = Get-Content "scripts/config.json" | ConvertFrom-Json
   az rest --method GET --url "$($config.cluster.uri)/v1/rest/mgmt" --resource $config.cluster.uri
   ```

3. Report connection status to user

### For `query` action:

1. Parse the query from arguments (after `|`)
2. Load cluster config from `scripts/config.json`
3. Get access token:
   ```powershell
   $token = az account get-access-token --resource $clusterUri --query accessToken -o tsv
   ```

4. Execute query:
   ```powershell
   $headers = @{ "Authorization" = "Bearer $token"; "Content-Type" = "application/json" }
   $body = @{ db = $database; csl = $query } | ConvertTo-Json
   $result = Invoke-RestMethod -Uri "$clusterUri/v1/rest/query" -Method POST -Headers $headers -Body $body
   ```

5. Parse and display results in table format

### For `report` action:

1. Load config from `scripts/config.json`
2. Execute all configured queries
3. Generate HTML report with:
   - Key metrics cards
   - Data tables
   - Insights/analysis
4. Save to `output/report_YYYY-MM-DD.html`
5. Display summary to user

### For `send` action:

1. Generate report (same as `report` action)
2. Send via Outlook:
   ```powershell
   $outlook = New-Object -ComObject Outlook.Application
   $mail = $outlook.CreateItem(0)
   $mail.To = $config.email.to
   $mail.Subject = "Analytics Report - $(Get-Date -Format 'yyyy-MM-dd')"
   $mail.HTMLBody = $htmlReport
   $mail.Send()
   ```
3. Confirm delivery to user

## Configuration

Load from `scripts/config.json`:

```json
{
  "cluster": {
    "uri": "https://your-cluster.region.kusto.windows.net",
    "database": "YourDatabase"
  },
  "queries": {
    "daily_summary": {
      "name": "Daily Summary",
      "file": "queries/daily_summary.kql"
    }
  },
  "email": {
    "to": "team@example.com",
    "subject": "Analytics Report - {date}"
  }
}
```

## Output Formats

### Query Results
```
📊 Query Results (5 rows)

| Category | Count | Percentage |
|----------|-------|------------|
| TypeA    | 1,234 | 45.2%      |
| TypeB    | 892   | 32.7%      |
| TypeC    | 601   | 22.1%      |
```

### Report Generation
```
✅ Report Generated Successfully!

📄 File: output/report_2026-01-17.html
📊 Sections: Key Metrics, Trends, Errors
📧 Ready to send (use /kusto_report send)
```

### Email Sent
```
✅ Report Sent!

📧 To: team@example.com
📋 Subject: Analytics Report - 2026-01-17
📊 Sections: 4
```

## Error Handling

- **Auth failed**: Prompt `az login`
- **Cluster unreachable**: Check VPN, verify cluster URL
- **Query error**: Display Kusto error message
- **Outlook error**: Check Outlook is running

## Security Notes

- Clear tokens after use
- Delete sensitive output files
- Never log raw query results with PII

## Time Saved

~30-45 minutes (manual query, analysis, formatting, emailing)
