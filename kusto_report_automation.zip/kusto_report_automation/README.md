# Kusto Analysis & Email Report Automation for Claude Code

Automate data analysis with Azure Data Explorer (Kusto) and generate beautiful email reports directly from Claude Code.

---

## ⚙️ Configuration Notes

> **Important:** This repository contains **templates and examples only**.

- `YourTable`, `YourDatabase`, `your-cluster` are **placeholders** — replace with your actual Kusto resources
- Email addresses like `team@example.com` are **examples only**
- All queries are **schema-agnostic templates** — customize column names for your data
- No real credentials, secrets, or connection strings are included

---

## Overview

This guide covers how to:
- Connect to Azure Data Explorer (Kusto) clusters
- Run KQL (Kusto Query Language) queries
- Process and analyze results
- Generate formatted HTML reports
- Send automated email summaries

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Claude Code   │────▶│  Kusto Cluster   │────▶│  Process Data   │────▶│  Email Report   │
│   (KQL Query)   │◀────│  (ADX)           │◀────│  (Analysis)     │◀────│  (Outlook)      │
└─────────────────┘     └──────────────────┘     └─────────────────┘     └─────────────────┘
```

---

## Prerequisites

1. **Azure Data Explorer Cluster** access
2. **Azure CLI** installed and authenticated
3. **PowerShell 5.1+**
4. **Microsoft Outlook** (for email sending)
5. **VPN Connection** (if cluster is internal)

---

## Authentication Setup

### Option 1: Azure CLI (Recommended)

```powershell
# Login to Azure
az login

# Verify account
az account show

# Test Kusto access
az kusto cluster show --name "your-cluster" --resource-group "your-rg"
```

### Option 2: Kusto CLI (kusto.cli)

```powershell
# Install Kusto CLI
dotnet tool install -g Microsoft.Azure.Kusto.Tools

# Connect to cluster
kusto "https://your-cluster.region.kusto.windows.net" -database "YourDatabase"
```

### Option 3: PowerShell with Azure Data Explorer Module

```powershell
# Install module
Install-Module Az.Kusto -Scope CurrentUser

# Connect
Connect-AzAccount

# Run query
Invoke-AzKustoQuery -ClusterUri "https://your-cluster.region.kusto.windows.net" `
    -Database "YourDatabase" `
    -Query "TableName | take 10"
```

---

## Configuration

Create `scripts/config.json`:

```json
{
  "cluster": {
    "uri": "https://your-cluster.region.kusto.windows.net",
    "database": "YourDatabase"
  },
  "queries": {
    "dailySummary": {
      "name": "Daily Summary",
      "file": "queries/daily_summary.kql",
      "description": "Aggregated daily metrics"
    },
    "errorAnalysis": {
      "name": "Error Analysis",
      "file": "queries/error_analysis.kql",
      "description": "Error categorization and trends"
    },
    "userMetrics": {
      "name": "User Metrics",
      "file": "queries/user_metrics.kql",
      "description": "User activity and engagement"
    }
  },
  "email": {
    "to": "team@example.com",
    "cc": "",
    "subject": "Daily Analytics Report - {date}",
    "sender": "Analytics Bot"
  },
  "output": {
    "saveResults": true,
    "outputDir": "output",
    "retentionDays": 7
  }
}
```

---

## Running Kusto Queries

### Method 1: Azure CLI REST API

```powershell
# Build query request
$body = @{
    db = "YourDatabase"
    csl = "YourTable | summarize Count=count() by Category | order by Count desc"
} | ConvertTo-Json

# Execute query
$result = az rest --method POST `
    --url "https://your-cluster.region.kusto.windows.net/v1/rest/query" `
    --body $body `
    --headers "Content-Type=application/json" `
    --resource "https://your-cluster.region.kusto.windows.net"

$data = $result | ConvertFrom-Json
```

### Method 2: Kusto.Cli

```powershell
# Save query to file
@"
YourTable
| where Timestamp > ago(1d)
| summarize Count=count() by Category
| order by Count desc
"@ | Out-File "query.kql"

# Execute and save results
kusto "https://your-cluster.region.kusto.windows.net" `
    -database "YourDatabase" `
    -execute ".show tables" `
    -lineMode:false > results.json
```

### Method 3: PowerShell Direct Connection

```powershell
function Invoke-KustoQuery {
    param(
        [string]$ClusterUri,
        [string]$Database,
        [string]$Query
    )

    # Get access token
    $token = az account get-access-token --resource $ClusterUri --query accessToken -o tsv

    # Build request
    $headers = @{
        "Authorization" = "Bearer $token"
        "Content-Type" = "application/json"
    }

    $body = @{
        db = $Database
        csl = $Query
    } | ConvertTo-Json

    # Execute query
    $response = Invoke-RestMethod `
        -Uri "$ClusterUri/v1/rest/query" `
        -Method POST `
        -Headers $headers `
        -Body $body

    return $response
}

# Usage
$results = Invoke-KustoQuery `
    -ClusterUri "https://your-cluster.region.kusto.windows.net" `
    -Database "YourDatabase" `
    -Query "Events | take 100"
```

---

## Query Examples (KQL)

### Daily Summary

```kql
// Daily metrics summary
Events
| where Timestamp > ago(1d)
| summarize
    TotalEvents = count(),
    UniqueUsers = dcount(UserId),
    AvgDuration = avg(Duration),
    ErrorRate = countif(Status == "Error") * 100.0 / count()
| extend ReportDate = now()
```

### Trend Analysis

```kql
// 7-day trend
Events
| where Timestamp > ago(7d)
| summarize DailyCount = count() by bin(Timestamp, 1d)
| order by Timestamp asc
| extend
    MovingAvg = avg(DailyCount) over (order by Timestamp rows between 2 preceding and current row),
    DayOverDay = DailyCount - prev(DailyCount)
```

### Category Breakdown

```kql
// Category distribution
Events
| where Timestamp > ago(1d)
| summarize Count = count() by Category
| extend Percentage = round(Count * 100.0 / toscalar(Events | where Timestamp > ago(1d) | count()), 1)
| order by Count desc
```

### Error Analysis

```kql
// Error categorization
Events
| where Timestamp > ago(1d) and Status == "Error"
| summarize
    Count = count(),
    FirstSeen = min(Timestamp),
    LastSeen = max(Timestamp),
    AffectedUsers = dcount(UserId)
    by ErrorCode, ErrorMessage
| order by Count desc
| take 20
```

### User Engagement

```kql
// User activity metrics
Events
| where Timestamp > ago(7d)
| summarize
    SessionCount = dcount(SessionId),
    EventCount = count(),
    AvgSessionDuration = avg(Duration)
    by UserId
| summarize
    TotalUsers = count(),
    HighEngagement = countif(EventCount > 100),
    MediumEngagement = countif(EventCount between (10 .. 100)),
    LowEngagement = countif(EventCount < 10)
```

---

## Processing Results

### Parse Kusto Response

```powershell
function Parse-KustoResult {
    param($Response)

    $tables = $Response.Tables
    if (-not $tables -or $tables.Count -eq 0) {
        return @()
    }

    $primaryTable = $tables | Where-Object { $_.TableName -eq "PrimaryResult" } | Select-Object -First 1
    if (-not $primaryTable) {
        $primaryTable = $tables[0]
    }

    $columns = $primaryTable.Columns
    $rows = $primaryTable.Rows

    $results = @()
    foreach ($row in $rows) {
        $obj = @{}
        for ($i = 0; $i -lt $columns.Count; $i++) {
            $obj[$columns[$i].ColumnName] = $row[$i]
        }
        $results += [PSCustomObject]$obj
    }

    return $results
}
```

### Analyze Data

```powershell
function Analyze-Results {
    param($Data)

    $analysis = @{
        TotalRecords = $Data.Count
        Summary = @{}
        Insights = @()
    }

    # Calculate statistics
    $numericColumns = $Data[0].PSObject.Properties |
        Where-Object { $_.Value -is [int] -or $_.Value -is [double] } |
        Select-Object -ExpandProperty Name

    foreach ($col in $numericColumns) {
        $values = $Data | Select-Object -ExpandProperty $col
        $analysis.Summary[$col] = @{
            Min = ($values | Measure-Object -Minimum).Minimum
            Max = ($values | Measure-Object -Maximum).Maximum
            Avg = [math]::Round(($values | Measure-Object -Average).Average, 2)
            Sum = ($values | Measure-Object -Sum).Sum
        }
    }

    # Generate insights
    if ($analysis.Summary.ErrorRate -and $analysis.Summary.ErrorRate.Avg -gt 5) {
        $analysis.Insights += "High error rate detected: $($analysis.Summary.ErrorRate.Avg)%"
    }

    return $analysis
}
```

---

## Generating HTML Report

### Report Template

```powershell
function New-HtmlReport {
    param(
        [string]$Title,
        [array]$Sections,
        [string]$Date = (Get-Date -Format "yyyy-MM-dd")
    )

    $sectionsHtml = ""
    foreach ($section in $Sections) {
        $sectionsHtml += @"
        <div style="margin-bottom: 32px;">
            <h2 style="color: #6366f1; font-size: 20px; margin-bottom: 16px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px;">
                $($section.Icon) $($section.Title)
            </h2>
            $($section.Content)
        </div>
"@
    }

    $html = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>$Title</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f3f4f6;">
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color: #f3f4f6;">
        <tr>
            <td align="center" style="padding: 40px 20px;">
                <table cellpadding="0" cellspacing="0" border="0" width="600" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                    <!-- Header -->
                    <tr>
                        <td style="padding: 32px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); border-radius: 12px 12px 0 0;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 700;">$Title</h1>
                            <p style="margin: 8px 0 0 0; color: rgba(255,255,255,0.8); font-size: 14px;">Report Date: $Date</p>
                        </td>
                    </tr>

                    <!-- Content -->
                    <tr>
                        <td style="padding: 32px;">
                            $sectionsHtml
                        </td>
                    </tr>

                    <!-- Footer -->
                    <tr>
                        <td style="padding: 24px 32px; background-color: #f9fafb; border-radius: 0 0 12px 12px; border-top: 1px solid #e5e7eb;">
                            <p style="margin: 0; color: #6b7280; font-size: 12px; text-align: center;">
                                Generated automatically by Claude Code Analytics
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
"@

    return $html
}
```

### Create Metrics Card

```powershell
function New-MetricsCard {
    param(
        [string]$Label,
        [string]$Value,
        [string]$Trend = "",
        [string]$TrendColor = "#10b981"
    )

    $trendHtml = if ($Trend) {
        "<div style='color: $TrendColor; font-size: 13px; font-weight: 600;'>$Trend</div>"
    } else { "" }

    return @"
    <td style="padding: 8px;">
        <div style="background: #f9fafb; border-radius: 12px; padding: 20px; text-align: center;">
            <div style="color: #6b7280; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">$Label</div>
            <div style="color: #111827; font-size: 28px; font-weight: 700; margin: 8px 0;">$Value</div>
            $trendHtml
        </div>
    </td>
"@
}
```

### Create Data Table

```powershell
function New-DataTable {
    param(
        [array]$Data,
        [array]$Columns,
        [int]$MaxRows = 10
    )

    # Header
    $headerHtml = "<tr>"
    foreach ($col in $Columns) {
        $headerHtml += "<th style='padding: 12px; text-align: left; background: #f3f4f6; color: #374151; font-weight: 600; font-size: 12px; text-transform: uppercase; border-bottom: 2px solid #e5e7eb;'>$($col.Label)</th>"
    }
    $headerHtml += "</tr>"

    # Rows
    $rowsHtml = ""
    $count = 0
    foreach ($row in $Data) {
        if ($count -ge $MaxRows) { break }
        $rowsHtml += "<tr>"
        foreach ($col in $Columns) {
            $value = $row.($col.Field)
            $style = "padding: 12px; border-bottom: 1px solid #e5e7eb; color: #374151; font-size: 14px;"
            if ($col.Color) {
                $style += " color: $($col.Color);"
            }
            $rowsHtml += "<td style='$style'>$value</td>"
        }
        $rowsHtml += "</tr>"
        $count++
    }

    return @"
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse: collapse;">
        $headerHtml
        $rowsHtml
    </table>
"@
}
```

---

## Complete Report Script

Create `scripts/generate_kusto_report.ps1`:

```powershell
<#
.SYNOPSIS
    Generates an analytics report from Kusto data and sends via email.

.PARAMETER ConfigPath
    Path to config.json

.PARAMETER SendEmail
    If true, sends the report via Outlook

.EXAMPLE
    .\generate_kusto_report.ps1 -ConfigPath "config.json" -SendEmail
#>

param(
    [string]$ConfigPath = "config.json",
    [switch]$SendEmail = $false,
    [switch]$SaveHtml = $true
)

# Load configuration
$config = Get-Content $ConfigPath | ConvertFrom-Json

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "  Kusto Analytics Report Generator" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan

# ============================================
# STEP 1: AUTHENTICATION
# ============================================

Write-Host "`n[1/5] Authenticating..." -ForegroundColor Yellow

try {
    $token = az account get-access-token --resource $config.cluster.uri --query accessToken -o tsv
    if (-not $token) { throw "Failed to get access token" }
    Write-Host "  Authentication successful" -ForegroundColor Green
} catch {
    Write-Host "  ERROR: Authentication failed. Run 'az login' first." -ForegroundColor Red
    Write-Host "  Note: VPN connection may be required." -ForegroundColor Yellow
    exit 1
}

# ============================================
# STEP 2: EXECUTE QUERIES
# ============================================

Write-Host "`n[2/5] Executing Kusto queries..." -ForegroundColor Yellow

$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type" = "application/json"
}

$queryResults = @{}

foreach ($queryKey in $config.queries.PSObject.Properties.Name) {
    $queryConfig = $config.queries.$queryKey
    Write-Host "  Running: $($queryConfig.name)..." -ForegroundColor Gray

    # Load query from file or use inline
    if ($queryConfig.file -and (Test-Path $queryConfig.file)) {
        $query = Get-Content $queryConfig.file -Raw
    } elseif ($queryConfig.query) {
        $query = $queryConfig.query
    } else {
        Write-Host "    Skipped: No query defined" -ForegroundColor Yellow
        continue
    }

    try {
        $body = @{ db = $config.cluster.database; csl = $query } | ConvertTo-Json
        $response = Invoke-RestMethod `
            -Uri "$($config.cluster.uri)/v1/rest/query" `
            -Method POST `
            -Headers $headers `
            -Body $body

        # Parse results
        $table = $response.Tables | Where-Object { $_.TableName -eq "PrimaryResult" } | Select-Object -First 1
        if (-not $table) { $table = $response.Tables[0] }

        $data = @()
        foreach ($row in $table.Rows) {
            $obj = @{}
            for ($i = 0; $i -lt $table.Columns.Count; $i++) {
                $obj[$table.Columns[$i].ColumnName] = $row[$i]
            }
            $data += [PSCustomObject]$obj
        }

        $queryResults[$queryKey] = $data
        Write-Host "    Retrieved $($data.Count) rows" -ForegroundColor Green

    } catch {
        Write-Host "    ERROR: $($_.Exception.Message)" -ForegroundColor Red
        $queryResults[$queryKey] = @()
    }
}

# ============================================
# STEP 3: ANALYZE DATA
# ============================================

Write-Host "`n[3/5] Analyzing results..." -ForegroundColor Yellow

$insights = @()

# Example analysis - customize based on your data
if ($queryResults.dailySummary -and $queryResults.dailySummary.Count -gt 0) {
    $summary = $queryResults.dailySummary[0]

    if ($summary.ErrorRate -and [double]$summary.ErrorRate -gt 5) {
        $insights += @{
            Type = "Warning"
            Message = "Error rate is elevated at $($summary.ErrorRate)%"
            Icon = "⚠️"
        }
    }

    if ($summary.UniqueUsers -and [int]$summary.UniqueUsers -gt 1000) {
        $insights += @{
            Type = "Success"
            Message = "Strong user engagement with $($summary.UniqueUsers) active users"
            Icon = "✅"
        }
    }
}

Write-Host "  Generated $($insights.Count) insights" -ForegroundColor Green

# ============================================
# STEP 4: GENERATE HTML REPORT
# ============================================

Write-Host "`n[4/5] Generating HTML report..." -ForegroundColor Yellow

$reportDate = Get-Date -Format "yyyy-MM-dd"
$reportTitle = "Analytics Report"

# Build sections
$sections = @()

# Summary Section
if ($queryResults.dailySummary -and $queryResults.dailySummary.Count -gt 0) {
    $s = $queryResults.dailySummary[0]
    $metricsHtml = @"
    <table cellpadding="0" cellspacing="0" border="0" width="100%">
        <tr>
            <td style="padding: 8px; width: 25%;">
                <div style="background: #f0fdf4; border-radius: 12px; padding: 20px; text-align: center;">
                    <div style="color: #166534; font-size: 11px; font-weight: 600; text-transform: uppercase;">Total Events</div>
                    <div style="color: #166534; font-size: 28px; font-weight: 700; margin: 8px 0;">$($s.TotalEvents)</div>
                </div>
            </td>
            <td style="padding: 8px; width: 25%;">
                <div style="background: #eff6ff; border-radius: 12px; padding: 20px; text-align: center;">
                    <div style="color: #1e40af; font-size: 11px; font-weight: 600; text-transform: uppercase;">Unique Users</div>
                    <div style="color: #1e40af; font-size: 28px; font-weight: 700; margin: 8px 0;">$($s.UniqueUsers)</div>
                </div>
            </td>
            <td style="padding: 8px; width: 25%;">
                <div style="background: #fef3c7; border-radius: 12px; padding: 20px; text-align: center;">
                    <div style="color: #92400e; font-size: 11px; font-weight: 600; text-transform: uppercase;">Avg Duration</div>
                    <div style="color: #92400e; font-size: 28px; font-weight: 700; margin: 8px 0;">$($s.AvgDuration)ms</div>
                </div>
            </td>
            <td style="padding: 8px; width: 25%;">
                <div style="background: #fef2f2; border-radius: 12px; padding: 20px; text-align: center;">
                    <div style="color: #991b1b; font-size: 11px; font-weight: 600; text-transform: uppercase;">Error Rate</div>
                    <div style="color: #991b1b; font-size: 28px; font-weight: 700; margin: 8px 0;">$($s.ErrorRate)%</div>
                </div>
            </td>
        </tr>
    </table>
"@
    $sections += @{ Title = "Key Metrics"; Icon = "📊"; Content = $metricsHtml }
}

# Insights Section
if ($insights.Count -gt 0) {
    $insightsHtml = ""
    foreach ($insight in $insights) {
        $bgColor = switch ($insight.Type) {
            "Warning" { "#fef3c7" }
            "Error" { "#fef2f2" }
            "Success" { "#f0fdf4" }
            default { "#f3f4f6" }
        }
        $insightsHtml += @"
        <div style="background: $bgColor; padding: 12px 16px; border-radius: 8px; margin-bottom: 8px;">
            <span style="font-size: 16px;">$($insight.Icon)</span>
            <span style="color: #374151; font-size: 14px; margin-left: 8px;">$($insight.Message)</span>
        </div>
"@
    }
    $sections += @{ Title = "Insights"; Icon = "💡"; Content = $insightsHtml }
}

# Error Analysis Section
if ($queryResults.errorAnalysis -and $queryResults.errorAnalysis.Count -gt 0) {
    $tableHtml = "<table cellpadding='0' cellspacing='0' border='0' width='100%' style='border-collapse: collapse;'>"
    $tableHtml += "<tr><th style='padding: 12px; text-align: left; background: #f3f4f6; font-size: 12px; border-bottom: 2px solid #e5e7eb;'>Error Code</th><th style='padding: 12px; text-align: left; background: #f3f4f6; font-size: 12px; border-bottom: 2px solid #e5e7eb;'>Count</th><th style='padding: 12px; text-align: left; background: #f3f4f6; font-size: 12px; border-bottom: 2px solid #e5e7eb;'>Affected Users</th></tr>"

    $count = 0
    foreach ($error in $queryResults.errorAnalysis) {
        if ($count -ge 5) { break }
        $tableHtml += "<tr><td style='padding: 12px; border-bottom: 1px solid #e5e7eb;'>$($error.ErrorCode)</td><td style='padding: 12px; border-bottom: 1px solid #e5e7eb;'>$($error.Count)</td><td style='padding: 12px; border-bottom: 1px solid #e5e7eb;'>$($error.AffectedUsers)</td></tr>"
        $count++
    }
    $tableHtml += "</table>"

    $sections += @{ Title = "Top Errors"; Icon = "⚠️"; Content = $tableHtml }
}

# Build final HTML
$sectionsHtml = ""
foreach ($section in $sections) {
    $sectionsHtml += @"
    <div style="margin-bottom: 32px;">
        <h2 style="color: #6366f1; font-size: 18px; margin-bottom: 16px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px;">
            $($section.Icon) $($section.Title)
        </h2>
        $($section.Content)
    </div>
"@
}

$htmlReport = @"
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>$reportTitle</title></head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #f3f4f6;">
    <table cellpadding="0" cellspacing="0" border="0" width="100%" style="background-color: #f3f4f6;">
        <tr>
            <td align="center" style="padding: 40px 20px;">
                <table cellpadding="0" cellspacing="0" border="0" width="600" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                    <tr>
                        <td style="padding: 32px; background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%); border-radius: 12px 12px 0 0;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 24px;">$reportTitle</h1>
                            <p style="margin: 8px 0 0 0; color: rgba(255,255,255,0.8); font-size: 14px;">$reportDate</p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 32px;">
                            $sectionsHtml
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 24px 32px; background-color: #f9fafb; border-radius: 0 0 12px 12px; border-top: 1px solid #e5e7eb;">
                            <p style="margin: 0; color: #6b7280; font-size: 12px; text-align: center;">
                                Generated by Claude Code Analytics
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
"@

Write-Host "  HTML report generated" -ForegroundColor Green

# Save HTML if requested
if ($SaveHtml) {
    $outputDir = $config.output.outputDir
    if (-not (Test-Path $outputDir)) {
        New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    }
    $htmlPath = Join-Path $outputDir "report_$reportDate.html"
    $htmlReport | Out-File -FilePath $htmlPath -Encoding UTF8
    Write-Host "  Saved to: $htmlPath" -ForegroundColor Gray
}

# ============================================
# STEP 5: SEND EMAIL
# ============================================

if ($SendEmail) {
    Write-Host "`n[5/5] Sending email report..." -ForegroundColor Yellow

    try {
        $outlook = New-Object -ComObject Outlook.Application
        $mail = $outlook.CreateItem(0)

        $mail.To = $config.email.to
        if ($config.email.cc) { $mail.CC = $config.email.cc }
        $mail.Subject = $config.email.subject -replace '\{date\}', $reportDate
        $mail.HTMLBody = $htmlReport

        $mail.Send()
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($outlook) | Out-Null

        Write-Host "  Email sent to: $($config.email.to)" -ForegroundColor Green

    } catch {
        Write-Host "  ERROR: Failed to send email: $_" -ForegroundColor Red
    }
} else {
    Write-Host "`n[5/5] Skipping email (use -SendEmail to send)" -ForegroundColor Gray
}

# ============================================
# CLEANUP (Security)
# ============================================

Write-Host "`n[Cleanup] Removing sensitive data..." -ForegroundColor Yellow

# Clear variables containing sensitive data
$token = $null
$queryResults = $null

# Optionally delete old output files
if ($config.output.retentionDays -gt 0) {
    $cutoff = (Get-Date).AddDays(-$config.output.retentionDays)
    Get-ChildItem $config.output.outputDir -Filter "*.html" |
        Where-Object { $_.LastWriteTime -lt $cutoff } |
        Remove-Item -Force
}

Write-Host "  Cleanup complete" -ForegroundColor Green

Write-Host "`n==================================================" -ForegroundColor Cyan
Write-Host "  Report Generation Complete!" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
```

---

## File Structure

```
kusto_report_automation/
├── scripts/
│   ├── generate_kusto_report.ps1    # Main report script
│   └── config.json                  # Configuration
├── queries/
│   ├── daily_summary.kql            # Daily metrics query
│   ├── error_analysis.kql           # Error breakdown query
│   └── user_metrics.kql             # User activity query
├── output/                          # Generated reports
│   └── report_2026-01-17.html
└── README.md                        # This file
```

---

## Security Best Practices

1. **Never commit credentials** - Use `az login` or environment variables
2. **Clean up results** - Delete sensitive data files after processing
3. **Use .gitignore** - Exclude output/, *.json with credentials
4. **VPN when required** - Connect before accessing internal clusters
5. **Minimal permissions** - Request only needed database access
6. **Audit queries** - Log what data is accessed and when

### Sample .gitignore

```gitignore
# Sensitive data
output/
*.csv
*.json
!config.sample.json

# Credentials
.env
*.pem
*.key

# Temporary files
*.tmp
*.log
```

---

## Troubleshooting

### "Unable to connect to cluster"

1. Check VPN connection
2. Verify cluster URL is correct
3. Run `az login` to refresh credentials

### "Access denied to database"

1. Verify you have database access
2. Check with your admin for permissions
3. Try accessing via Azure Data Explorer web UI first

### "Query timeout"

1. Add `| take 1000` to limit results
2. Use `set notruncation;` for large results
3. Optimize query with filters early

### "Outlook COM error"

1. Ensure Outlook is installed and configured
2. Run PowerShell as same user as Outlook
3. Check Outlook is not in offline mode

---

## Enterprise Compliance & Data Security

Azure Data Explorer (Kusto) is enterprise-grade and meets strict compliance requirements for handling sensitive data.

### Compliance Certifications

| Standard | Status | Use Case |
|----------|--------|----------|
| **SOC 1, 2, 3** | ✅ Certified | Financial controls, security audits |
| **ISO 27001/27017/27018** | ✅ Certified | Information security management |
| **HIPAA/HITECH** | ✅ BAA Available | Healthcare data (PHI) |
| **GDPR** | ✅ Compliant | EU data protection |
| **FedRAMP High** | ✅ Certified | US Government workloads |
| **PCI DSS Level 1** | ✅ Compliant | Payment card data |
| **HITRUST CSF** | ✅ Certified | Healthcare security |
| **CCPA** | ✅ Compliant | California privacy law |
| **CSA STAR** | ✅ Certified | Cloud security alliance |

### Security Features

| Feature | Description |
|---------|-------------|
| **Encryption at Rest** | AES-256 encryption, Customer-Managed Keys (CMK) supported |
| **Encryption in Transit** | TLS 1.2+ enforced for all connections |
| **Azure AD / Entra ID** | Full RBAC, Conditional Access, MFA support |
| **Private Link** | VNet isolation, no public internet exposure |
| **Row-Level Security (RLS)** | Restrict data access per user/role |
| **Dynamic Data Masking** | Auto-mask PII/sensitive data in query results |
| **Audit Logging** | Complete query audit trail for compliance |
| **Managed Identity** | No credentials stored in code |
| **Microsoft Purview** | Data governance, lineage, and cataloging |

### Data Residency & Sovereignty

- **Region-specific clusters** - Data stays in your chosen Azure region
- **Geo-redundancy control** - You choose replication locations
- **Data never leaves tenant** - Queries execute server-side
- **Configurable retention** - Auto-delete per compliance requirements

### Why This Is Safe for Claude Code Integration

1. **Server-side execution** - Raw data never downloaded to local machine
2. **Token-based authentication** - No passwords stored, tokens auto-expire
3. **Aggregated results only** - Reports show summaries, not raw PII
4. **Full audit trail** - Every query logged in Azure Monitor
5. **Auto-cleanup** - Scripts delete sensitive files after processing

### Compliance Best Practices for Your Scripts

```powershell
# 1. Use aggregations instead of raw data
# Good:
YourTable | summarize Count=count() by Category

# Avoid:
YourTable | project UserId, Email, Name

# 2. Enable auto-cleanup in config
"security": {
    "cleanupAfterSend": true,
    "maskPII": true
}

# 3. Set short retention for output files
"output": {
    "retentionDays": 1
}

# 4. Use Row-Level Security for sensitive tables
.add table YourTable policy row_level_security enable "SecurityPolicy"
```

### Compliance Resources

- [Azure Compliance Offerings](https://docs.microsoft.com/azure/compliance/)
- [Azure Data Explorer Security](https://docs.microsoft.com/azure/data-explorer/security)
- [Microsoft Trust Center](https://www.microsoft.com/trust-center)
- [Azure Data Explorer GDPR](https://docs.microsoft.com/azure/data-explorer/gdpr)

---

## 🔐 Security & Privacy

This repository is designed with security in mind:

- **No API keys, secrets, or credentials** are included in this repository
- **All configuration files use placeholder or sample values only**
- **PII masking and cleanup behaviors** are enabled by default where applicable
- **Token-based authentication** — credentials are never stored in scripts
- **Auto-cleanup** — sensitive output files are deleted after processing

> Users are responsible for securing their own credentials and following their organization's security policies.

---

## 📧 Email & Integrations Disclaimer

- **Email delivery is not bundled** — this repo provides templates only
- Users must configure their own **Outlook/SMTP/email infrastructure**
- External integrations (webhooks, APIs) require **user configuration**
- Test thoroughly in a **non-production environment** before deploying

---

## 📄 License

MIT License - Free to use, modify, and distribute.

See the [LICENSE](LICENSE) file for full details.

---

**Happy analyzing!** 📊
