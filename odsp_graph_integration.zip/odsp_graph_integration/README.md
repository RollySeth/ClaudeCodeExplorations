# OneDrive & SharePoint Integration with MS Graph API for Claude Code

Connect Claude Code to OneDrive for Business (ODSP) and SharePoint for seamless document management - create, upload, search, fetch, and organize files directly from your terminal.

---

## Overview

Microsoft Graph API provides unified access to OneDrive and SharePoint, enabling Claude Code skills to:

- **Create** - Generate new documents (Word, Excel, PowerPoint, PDF)
- **Upload** - Push local files to cloud storage
- **Search** - Find documents by name, content, or metadata
- **Fetch** - Download files for processing
- **Organize** - Move, copy, rename, delete files and folders
- **Share** - Generate sharing links and manage permissions

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   Claude Code   │────▶│  MS Graph API    │────▶│  OneDrive /     │
│   (Skills)      │◀────│  (REST/SDK)      │◀────│  SharePoint     │
└─────────────────┘     └──────────────────┘     └─────────────────┘
```

---

## Architecture

### How It Works

1. **Authentication**: Claude Code authenticates via Azure AD (OAuth 2.0)
2. **API Calls**: Skills make REST calls to Graph API endpoints
3. **Operations**: Graph API translates requests to ODSP operations
4. **Response**: Results returned as JSON for processing

### Key Endpoints

| Resource | Endpoint | Description |
|----------|----------|-------------|
| My OneDrive | `/me/drive` | User's personal OneDrive |
| OneDrive Root | `/me/drive/root` | Root folder |
| Item by Path | `/me/drive/root:/{path}` | Access by file path |
| Item by ID | `/me/drive/items/{id}` | Access by item ID |
| SharePoint Site | `/sites/{site-id}` | SharePoint site |
| Site Drive | `/sites/{site-id}/drive` | Site's document library |
| Search | `/me/drive/search(q='{query}')` | Search files |

---

## Authentication Setup

### Option 1: Azure CLI (Recommended for Claude Code)

```powershell
# Login to Azure
az login

# Set default subscription (if multiple)
az account set --subscription "Your Subscription"

# Test Graph API access
az rest --method GET --url "https://graph.microsoft.com/v1.0/me/drive"
```

### Option 2: Microsoft Graph PowerShell SDK

```powershell
# Install SDK
Install-Module Microsoft.Graph -Scope CurrentUser

# Connect with required scopes
Connect-MgGraph -Scopes @(
    "Files.ReadWrite.All",
    "Sites.ReadWrite.All",
    "User.Read"
)

# Verify connection
Get-MgContext
```

### Option 3: Personal Access Token (PAT)

For automated scripts, use an Azure AD app registration:

1. Register app in Azure Portal → Azure Active Directory → App registrations
2. Add API permissions: `Files.ReadWrite.All`, `Sites.ReadWrite.All`
3. Create client secret or certificate
4. Use MSAL for token acquisition

```powershell
# Environment variables for app auth
$env:AZURE_CLIENT_ID = "your-app-id"
$env:AZURE_CLIENT_SECRET = "your-secret"
$env:AZURE_TENANT_ID = "your-tenant-id"
```

---

## Required Permissions (Scopes)

| Permission | Type | Description |
|------------|------|-------------|
| `Files.Read` | Delegated | Read user's files |
| `Files.ReadWrite` | Delegated | Read/write user's files |
| `Files.ReadWrite.All` | Delegated | Read/write all files user can access |
| `Sites.Read.All` | Delegated | Read SharePoint sites |
| `Sites.ReadWrite.All` | Delegated | Read/write SharePoint sites |
| `User.Read` | Delegated | Read user profile |

### Minimal Scopes for Common Operations

```powershell
# Read-only access
Connect-MgGraph -Scopes "Files.Read", "Sites.Read.All"

# Full read/write access
Connect-MgGraph -Scopes "Files.ReadWrite.All", "Sites.ReadWrite.All"
```

---

## Core Operations

### 1. List Files and Folders

```powershell
# List root folder contents
az rest --method GET --url "https://graph.microsoft.com/v1.0/me/drive/root/children"

# List specific folder
az rest --method GET --url "https://graph.microsoft.com/v1.0/me/drive/root:/Documents:/children"

# With PowerShell SDK
Get-MgDriveRootChild -DriveId (Get-MgUserDefaultDrive -UserId "me").Id
```

### 2. Upload Files

```powershell
# Small files (< 4MB) - Simple upload
$filePath = "C:\docs\report.docx"
$fileName = "report.docx"
$content = [System.IO.File]::ReadAllBytes($filePath)
$base64 = [Convert]::ToBase64String($content)

az rest --method PUT `
    --url "https://graph.microsoft.com/v1.0/me/drive/root:/Documents/$fileName:/content" `
    --body "@$filePath" `
    --headers "Content-Type=application/octet-stream"

# With PowerShell SDK
Set-MgDriveItemContent -DriveId $driveId -DriveItemId "root:/Documents/$fileName:" -BodyParameter (Get-Content $filePath -Raw)
```

#### Large File Upload (> 4MB)

```powershell
# Create upload session
$uploadSession = az rest --method POST `
    --url "https://graph.microsoft.com/v1.0/me/drive/root:/LargeFile.zip:/createUploadSession" `
    --body '{"item": {"@microsoft.graph.conflictBehavior": "rename"}}' `
    --headers "Content-Type=application/json" | ConvertFrom-Json

# Upload in chunks (simplified)
$uploadUrl = $uploadSession.uploadUrl
# Use chunked upload with Content-Range headers
```

### 3. Download Files

```powershell
# Get download URL
$item = az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/me/drive/root:/Documents/report.docx" | ConvertFrom-Json

# Download content
Invoke-WebRequest -Uri $item.'@microsoft.graph.downloadUrl' -OutFile "C:\downloads\report.docx"

# Or get content directly
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/me/drive/root:/Documents/report.docx:/content" `
    --output-file "C:\downloads\report.docx"
```

### 4. Search Files

```powershell
# Search by filename
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/me/drive/search(q='quarterly report')"

# Search in SharePoint site
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/sites/{site-id}/drive/search(q='budget')"

# With PowerShell SDK
Search-MgDrive -DriveId $driveId -Q "quarterly report"
```

### 5. Create Folders

```powershell
# Create folder
$body = @{
    name = "New Folder"
    folder = @{}
    "@microsoft.graph.conflictBehavior" = "rename"
} | ConvertTo-Json

az rest --method POST `
    --url "https://graph.microsoft.com/v1.0/me/drive/root/children" `
    --body $body `
    --headers "Content-Type=application/json"
```

### 6. Move/Copy Files

```powershell
# Move file
$body = @{
    parentReference = @{
        path = "/drive/root:/Archive"
    }
    name = "report_2024.docx"  # Optional: rename
} | ConvertTo-Json

az rest --method PATCH `
    --url "https://graph.microsoft.com/v1.0/me/drive/items/{item-id}" `
    --body $body `
    --headers "Content-Type=application/json"

# Copy file (async operation)
$body = @{
    parentReference = @{
        driveId = $targetDriveId
        id = $targetFolderId
    }
    name = "report_copy.docx"
} | ConvertTo-Json

az rest --method POST `
    --url "https://graph.microsoft.com/v1.0/me/drive/items/{item-id}/copy" `
    --body $body `
    --headers "Content-Type=application/json"
```

### 7. Delete Files

```powershell
# Delete (moves to recycle bin)
az rest --method DELETE `
    --url "https://graph.microsoft.com/v1.0/me/drive/items/{item-id}"

# Permanent delete (from recycle bin)
az rest --method DELETE `
    --url "https://graph.microsoft.com/v1.0/me/drive/items/{item-id}/permanentDelete"
```

### 8. Share Files

```powershell
# Create sharing link
$body = @{
    type = "view"  # view, edit, embed
    scope = "organization"  # anonymous, organization, users
} | ConvertTo-Json

$link = az rest --method POST `
    --url "https://graph.microsoft.com/v1.0/me/drive/items/{item-id}/createLink" `
    --body $body `
    --headers "Content-Type=application/json" | ConvertFrom-Json

Write-Host "Share URL: $($link.link.webUrl)"
```

---

## SharePoint Specific Operations

### Get Site Information

```powershell
# Get site by URL
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/sites/contoso.sharepoint.com:/sites/TeamSite"

# List all sites
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/sites?search=*"
```

### Access Document Libraries

```powershell
# List document libraries in a site
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/sites/{site-id}/drives"

# Access specific library
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/sites/{site-id}/drives/{drive-id}/root/children"
```

### Work with Lists

```powershell
# Get lists in a site
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/sites/{site-id}/lists"

# Get list items
az rest --method GET `
    --url "https://graph.microsoft.com/v1.0/sites/{site-id}/lists/{list-id}/items?expand=fields"
```

---

## Claude Code Skill Integration

### Example: Document Upload Skill

Create `.claude/commands/upload_doc.md`:

```markdown
# /upload_doc - Upload to OneDrive

Upload a local file to OneDrive.

## Usage
/upload_doc <local_path> | [destination_folder]

## Instructions

1. Parse arguments:
   - local_path: Path to local file
   - destination_folder: OneDrive path (default: /Documents)

2. Verify file exists locally

3. Execute upload:
   ```powershell
   $fileName = Split-Path $localPath -Leaf
   az rest --method PUT `
       --url "https://graph.microsoft.com/v1.0/me/drive/root:/$destFolder/$fileName:/content" `
       --body "@$localPath" `
       --headers "Content-Type=application/octet-stream"
   ```

4. Return uploaded file URL
```

### Example: Document Search Skill

Create `.claude/commands/search_docs.md`:

```markdown
# /search_docs - Search OneDrive/SharePoint

Search for documents across OneDrive and SharePoint.

## Usage
/search_docs <query>

## Instructions

1. Execute search:
   ```powershell
   $results = az rest --method GET `
       --url "https://graph.microsoft.com/v1.0/me/drive/search(q='$query')" | ConvertFrom-Json
   ```

2. Format and display results with:
   - File name
   - Location
   - Last modified
   - Web URL
```

### Example: Document Organizer Skill

```markdown
# /organize_docs - Organize Documents

Move files to appropriate folders based on type or date.

## Usage
/organize_docs <source_folder> | <rules>

## Rules Examples
- by-type: Group by file extension
- by-date: Group by modified date
- by-project: Group by project prefix
```

---

## PowerShell Helper Module

Create `scripts/ODSPHelper.psm1`:

```powershell
function Get-ODSPItem {
    param([string]$Path)
    $url = "https://graph.microsoft.com/v1.0/me/drive/root:/${Path}"
    az rest --method GET --url $url | ConvertFrom-Json
}

function Upload-ODSPFile {
    param(
        [string]$LocalPath,
        [string]$DestinationPath
    )
    $fileName = Split-Path $LocalPath -Leaf
    $url = "https://graph.microsoft.com/v1.0/me/drive/root:/${DestinationPath}/${fileName}:/content"
    az rest --method PUT --url $url --body "@$LocalPath" --headers "Content-Type=application/octet-stream" | ConvertFrom-Json
}

function Search-ODSP {
    param([string]$Query)
    $url = "https://graph.microsoft.com/v1.0/me/drive/search(q='$Query')"
    (az rest --method GET --url $url | ConvertFrom-Json).value
}

function New-ODSPFolder {
    param(
        [string]$ParentPath,
        [string]$FolderName
    )
    $body = @{ name = $FolderName; folder = @{} } | ConvertTo-Json
    $url = "https://graph.microsoft.com/v1.0/me/drive/root:/${ParentPath}:/children"
    az rest --method POST --url $url --body $body --headers "Content-Type=application/json" | ConvertFrom-Json
}

function Move-ODSPItem {
    param(
        [string]$ItemId,
        [string]$DestinationPath
    )
    $body = @{ parentReference = @{ path = "/drive/root:/$DestinationPath" } } | ConvertTo-Json
    $url = "https://graph.microsoft.com/v1.0/me/drive/items/$ItemId"
    az rest --method PATCH --url $url --body $body --headers "Content-Type=application/json" | ConvertFrom-Json
}

function Get-ODSPShareLink {
    param(
        [string]$ItemId,
        [string]$Type = "view",
        [string]$Scope = "organization"
    )
    $body = @{ type = $Type; scope = $Scope } | ConvertTo-Json
    $url = "https://graph.microsoft.com/v1.0/me/drive/items/$ItemId/createLink"
    (az rest --method POST --url $url --body $body --headers "Content-Type=application/json" | ConvertFrom-Json).link.webUrl
}

Export-ModuleMember -Function *
```

---

## Common Use Cases

### 1. Backup Local Project to OneDrive

```powershell
# Zip and upload project
Compress-Archive -Path "C:\Projects\MyApp" -DestinationPath "C:\temp\MyApp.zip"
Upload-ODSPFile -LocalPath "C:\temp\MyApp.zip" -DestinationPath "Backups/Projects"
```

### 2. Sync Documentation

```powershell
# Download all docs from SharePoint
$docs = az rest --method GET --url "https://graph.microsoft.com/v1.0/sites/{site-id}/drive/root:/Documentation:/children" | ConvertFrom-Json
foreach ($doc in $docs.value) {
    Invoke-WebRequest -Uri $doc.'@microsoft.graph.downloadUrl' -OutFile "C:\LocalDocs\$($doc.name)"
}
```

### 3. Archive Old Files

```powershell
# Find and move files older than 1 year
$oldFiles = Search-ODSP -Query "modified<2025-01-01"
foreach ($file in $oldFiles) {
    Move-ODSPItem -ItemId $file.id -DestinationPath "Archive/2024"
}
```

### 4. Generate Report from SharePoint Data

```powershell
# Fetch list data and create report
$items = az rest --method GET --url "https://graph.microsoft.com/v1.0/sites/{site-id}/lists/{list-id}/items?expand=fields" | ConvertFrom-Json
$items.value | Select-Object -ExpandProperty fields | Export-Csv "report.csv"
Upload-ODSPFile -LocalPath "report.csv" -DestinationPath "Reports"
```

---

## Error Handling

### Common Errors

| Error Code | Meaning | Solution |
|------------|---------|----------|
| 401 | Unauthorized | Re-authenticate: `az login` |
| 403 | Forbidden | Check permissions/scopes |
| 404 | Not Found | Verify path/ID exists |
| 409 | Conflict | File already exists, use conflictBehavior |
| 429 | Throttled | Wait and retry with backoff |
| 507 | Storage Full | Free up OneDrive space |

### Retry Logic

```powershell
function Invoke-GraphWithRetry {
    param(
        [string]$Method,
        [string]$Url,
        [int]$MaxRetries = 3
    )

    for ($i = 0; $i -lt $MaxRetries; $i++) {
        try {
            return az rest --method $Method --url $Url | ConvertFrom-Json
        } catch {
            if ($_.Exception.Message -match "429") {
                Start-Sleep -Seconds ([math]::Pow(2, $i) * 5)
            } else {
                throw
            }
        }
    }
}
```

---

## Security Best Practices

1. **Use minimal scopes** - Only request permissions you need
2. **Don't hardcode credentials** - Use environment variables or Azure Key Vault
3. **Audit access** - Review Azure AD sign-in logs
4. **Use delegated permissions** - Prefer user context over application context
5. **Rotate secrets** - Regularly rotate app secrets/certificates
6. **Enable MFA** - Require multi-factor authentication

---

## Troubleshooting

### Check Authentication Status

```powershell
# Azure CLI
az account show

# Graph PowerShell
Get-MgContext

# Test API access
az rest --method GET --url "https://graph.microsoft.com/v1.0/me"
```

### Debug API Calls

```powershell
# Verbose output
az rest --method GET --url "https://graph.microsoft.com/v1.0/me/drive" --verbose

# Check raw response
az rest --method GET --url "https://graph.microsoft.com/v1.0/me/drive" --output json
```

### Common Issues

**"Access token validation failure"**
```powershell
az logout
az login
```

**"Resource not found"**
- Verify the path exists
- Check for typos in site/drive IDs
- Ensure you have access to the resource

**"Insufficient privileges"**
```powershell
# Check current scopes
(Get-MgContext).Scopes

# Reconnect with additional scopes
Connect-MgGraph -Scopes "Files.ReadWrite.All", "Sites.ReadWrite.All"
```

---

## Quick Reference

### URL Patterns

```
# OneDrive
/me/drive                           # My drive
/me/drive/root                      # Root folder
/me/drive/root/children             # Root contents
/me/drive/root:/{path}              # Item by path
/me/drive/items/{id}                # Item by ID
/me/drive/search(q='{query}')       # Search

# SharePoint
/sites/{host}:/{path}               # Site by URL
/sites/{site-id}                    # Site by ID
/sites/{site-id}/drive              # Default library
/sites/{site-id}/drives             # All libraries
/sites/{site-id}/lists              # All lists
```

### Common Headers

```
Content-Type: application/json
Content-Type: application/octet-stream  # For file uploads
Prefer: respond-async                   # For long operations
```

---

## Resources

- [Microsoft Graph Documentation](https://docs.microsoft.com/graph/)
- [Graph Explorer](https://developer.microsoft.com/graph/graph-explorer)
- [OneDrive API Reference](https://docs.microsoft.com/onedrive/developer/)
- [SharePoint REST API](https://docs.microsoft.com/sharepoint/dev/sp-add-ins/get-to-know-the-sharepoint-rest-service)

---

## License

MIT License - Free to use, modify, and distribute.

---

**Happy document managing!**
