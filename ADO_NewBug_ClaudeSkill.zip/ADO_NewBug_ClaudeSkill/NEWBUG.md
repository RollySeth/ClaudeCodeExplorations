# /newbug - Azure DevOps Bug Filing Skill

File bugs directly to Azure DevOps from Claude Code with automatic categorization and formatting.

## Usage

```
/newbug <title> | <details> | <image_path>
```

**Arguments (separated by `|`):**
- **Title** (required): Brief bug title
- **Details** (optional): Description, repro steps, or context
- **Image Path** (optional): Local path to screenshot for attachment

## Examples

```
/newbug Login button not responding

/newbug Login button not responding | Clicking the button does nothing on mobile Safari

/newbug Login button not responding | Button unresponsive on iOS | C:\screenshots\login_bug.png
```

## Configuration

Before using this skill, configure your ADO settings in the `config.json` file:

```json
{
  "organization": "your-org",
  "project": "YourProject",
  "defaultAreaPath": "YourProject\\Team\\Component",
  "defaultIterationPath": "YourProject\\Sprint 1",
  "parentFeatureId": "12345",
  "categories": [
    {
      "id": "11111",
      "name": "UI Issues",
      "keywords": ["button", "layout", "display", "UI", "visual"],
      "areaPath": "YourProject\\Team\\Frontend"
    },
    {
      "id": "22222",
      "name": "API Issues",
      "keywords": ["api", "endpoint", "request", "response", "server"],
      "areaPath": "YourProject\\Team\\Backend"
    },
    {
      "id": "33333",
      "name": "Performance",
      "keywords": ["slow", "latency", "timeout", "performance", "speed"],
      "areaPath": "YourProject\\Team\\Backend"
    }
  ]
}
```

## How It Works

1. **Parse Input**: Extracts title, details, and image path from arguments
2. **Auto-Categorize**: Analyzes bug title/description to match relevant category
3. **Generate Report**: Creates formatted bug with:
   - Title
   - Description with repro steps
   - Expected vs Actual behavior
   - Parent work item link
   - Proper Area Path assignment
4. **Create in ADO**: Uses Azure CLI to create the bug
5. **Return Link**: Provides direct URL to the created bug

## Bug Report Format

The skill generates bugs with this structure:

```markdown
## Description
[User-provided details or auto-generated from title]

## Repro Steps
1. [Step 1]
2. [Step 2]
3. [Step 3]

## Expected Behavior
[What should happen]

## Actual Behavior
[What actually happens]

## Environment
- Browser/Device: [If provided]
- Date Reported: [Auto-generated]

## Additional Context
[Any extra details]
```

## Category Matching

The skill automatically assigns bugs to the right category based on keywords:

| Category | Example Keywords | Typical Area Path |
|----------|------------------|-------------------|
| UI Issues | button, layout, display, CSS | Frontend |
| API Issues | endpoint, request, 500 error | Backend |
| Performance | slow, timeout, latency | Backend |
| Data Issues | missing, incorrect, sync | Data |
| Auth Issues | login, permission, access | Security |

Configure your own categories in `config.json` to match your team's structure.

## Prerequisites

1. **Azure CLI** installed and authenticated
2. **Azure DevOps Extension** for Azure CLI
3. **PAT Token** or Azure AD authentication configured
4. **config.json** configured with your ADO settings

## Setup

See `README.md` for complete setup instructions.

## Output

After successful creation:

```
✅ Bug Created Successfully!

🔗 URL: https://dev.azure.com/your-org/YourProject/_workitems/edit/98765

📋 Details:
   Title: Login button not responding
   ID: 98765
   Parent PBI: UI Issues (#11111)
   Area Path: YourProject\Team\Frontend

📎 Remember to attach: C:\screenshots\login_bug.png
```

## Time Saved

~5 minutes per bug (navigating ADO, filling forms, categorizing, formatting)

## License

MIT License - Free to use, modify, and distribute.
