# /newbug - Azure DevOps Bug Filing

File a bug directly to Azure DevOps with automatic categorization.

## Usage

```
/newbug <title> | <details> | <image_path>
```

## Arguments

- **Title** (required): Brief bug title
- **Details** (optional): Description, repro steps, context
- **Image Path** (optional): Screenshot path for attachment reminder

## Instructions

1. **Parse Arguments** (separated by `|`):
   - First: Bug title (required)
   - Second: Bug details (optional)
   - Third: Image path (optional)

2. **Load Configuration**:
   - Read `scripts/config.json` for ADO settings and categories

3. **Auto-Categorize Bug**:
   - Analyze title and details for keywords
   - Match against category keywords in config
   - Select best matching category
   - Default to "General" if no match

4. **Generate Bug Report**:
   ```markdown
   ## Description
   [User-provided details]

   ## Repro Steps
   1. [Generated or provided steps]

   ## Expected Behavior
   [What should happen]

   ## Actual Behavior
   [The bug - what actually happens]

   ## Environment
   - Date: [Today's date]
   - Reporter: Claude Code
   ```

5. **Create Bug via PowerShell**:
   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File "scripts/create_bug.ps1" `
     -Title "<bug title>" `
     -Description "<full description>" `
     -CategoryId "<matched category id>"
   ```

6. **Parse Result**:
   - Extract bug ID and URL from JSON response
   - Display success message with link

7. **Remind About Attachment**:
   - If image path provided, remind user to upload it manually

## Example Output

```
✅ Bug Created Successfully!

🔗 URL: https://dev.azure.com/org/project/_workitems/edit/12345

📋 Details:
   Title: Login button not responding
   ID: 12345
   Category: UI/Frontend Issues
   Area Path: Project\Team\Frontend

📎 Attachment Reminder: Upload C:\screenshots\bug.png to the bug
```

## Category Matching Logic

Match keywords in title/description against config categories:

| Category | Keywords |
|----------|----------|
| UI/Frontend | button, layout, display, CSS, visual, click |
| API/Backend | API, endpoint, server, 500, timeout, request |
| Performance | slow, latency, memory, freeze, loading |
| Auth/Security | login, permission, access, token, session |
| Data | missing, incorrect, sync, duplicate, save |

## Error Handling

- If Azure CLI not found: Prompt user to install
- If auth fails: Prompt to run `az login` or set PAT
- If config missing: Point to README.md setup guide
- If creation fails: Show error and suggest manual filing

## Time Saved

~5 minutes per bug (opening ADO, navigating, filling forms, categorizing)
