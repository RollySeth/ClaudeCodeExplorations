<#
.SYNOPSIS
    Creates a bug in Azure DevOps from Claude Code.

.DESCRIPTION
    This script creates a formatted bug work item in Azure DevOps with automatic
    categorization based on keywords. Designed to work with the /newbug Claude Code skill.

.PARAMETER Title
    The bug title (required)

.PARAMETER Description
    Bug description and details (optional)

.PARAMETER CategoryId
    The category/PBI ID to link the bug to (optional)

.EXAMPLE
    .\create_bug.ps1 -Title "Login button broken" -Description "Button doesn't respond" -CategoryId "11111"

.NOTES
    Requires:
    - Azure CLI installed
    - Azure DevOps extension (az extension add --name azure-devops)
    - Authentication configured (PAT token or az login)
    - config.json in the same directory
#>

param(
    [Parameter(Mandatory=$true)]
    [string]$Title,

    [Parameter(Mandatory=$false)]
    [string]$Description = "",

    [Parameter(Mandatory=$false)]
    [string]$CategoryId = ""
)

# ============================================
# CONFIGURATION
# ============================================

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath = Join-Path $scriptDir "config.json"

# Check if config exists
if (-not (Test-Path $configPath)) {
    Write-Error "Configuration file not found: $configPath"
    Write-Error "Copy config.sample.json to config.json and update with your ADO settings."
    @{
        success = $false
        error = "Configuration file not found. See README.md for setup instructions."
    } | ConvertTo-Json
    exit 1
}

# Load configuration
try {
    $config = Get-Content $configPath -Raw | ConvertFrom-Json
} catch {
    Write-Error "Failed to parse config.json: $_"
    @{
        success = $false
        error = "Invalid config.json format"
    } | ConvertTo-Json
    exit 1
}

# ============================================
# CATEGORY MATCHING
# ============================================

function Find-Category {
    param(
        [string]$Title,
        [string]$Description,
        [string]$CategoryId,
        [array]$Categories
    )

    # If CategoryId provided, use it directly
    if ($CategoryId) {
        $match = $Categories | Where-Object { $_.id -eq $CategoryId } | Select-Object -First 1
        if ($match) { return $match }
    }

    # Auto-match based on keywords
    $searchText = "$Title $Description".ToLower()
    $bestMatch = $null
    $bestScore = 0

    foreach ($cat in $Categories) {
        if ($cat.keywords -and $cat.keywords.Count -gt 0) {
            $score = 0
            foreach ($keyword in $cat.keywords) {
                if ($searchText -match [regex]::Escape($keyword.ToLower())) {
                    $score++
                }
            }
            if ($score -gt $bestScore) {
                $bestScore = $score
                $bestMatch = $cat
            }
        }
    }

    # Return best match or default (last category)
    if ($bestMatch) {
        return $bestMatch
    } else {
        return $Categories | Select-Object -Last 1
    }
}

$category = Find-Category -Title $Title -Description $Description -CategoryId $CategoryId -Categories $config.categories

# ============================================
# BUILD BUG DESCRIPTION
# ============================================

$today = Get-Date -Format "yyyy-MM-dd"
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

# Generate repro steps if not provided
$reproSteps = if ($Description -match "step|1\.|2\.|3\.") {
    $Description
} else {
    @"
1. Navigate to the affected area
2. Perform the action described
3. Observe the unexpected behavior
"@
}

$fullDescription = @"
## Description

$Description

## Repro Steps

$reproSteps

## Expected Behavior

[Describe what should happen]

## Actual Behavior

[Describe what actually happens - the bug]

## Environment

- **Date Reported:** $today
- **Reporter:** Filed via Claude Code
- **Category:** $($category.name)

## Additional Context

[Add any other context, screenshots, or logs here]

---
*Bug filed automatically via Claude Code /newbug skill*
"@

# ============================================
# CREATE BUG IN ADO
# ============================================

Write-Host "Creating bug in Azure DevOps..." -ForegroundColor Yellow
Write-Host "  Organization: $($config.organization)" -ForegroundColor Gray
Write-Host "  Project: $($config.project)" -ForegroundColor Gray
Write-Host "  Area Path: $($category.areaPath)" -ForegroundColor Gray
Write-Host "  Category: $($category.name)" -ForegroundColor Gray

try {
    # Create the work item
    $result = az boards work-item create `
        --title $Title `
        --type "Bug" `
        --description $fullDescription `
        --area $category.areaPath `
        --organization $config.organization `
        --project $config.project `
        --output json 2>&1

    if ($LASTEXITCODE -eq 0) {
        $bug = $result | ConvertFrom-Json
        $bugUrl = "$($config.organization)/$($config.project)/_workitems/edit/$($bug.id)"

        Write-Host ""
        Write-Host "Bug created successfully!" -ForegroundColor Green
        Write-Host "  ID: $($bug.id)" -ForegroundColor Cyan
        Write-Host "  URL: $bugUrl" -ForegroundColor Cyan

        # Output JSON result for Claude Code
        @{
            success = $true
            id = $bug.id
            url = $bugUrl
            title = $Title
            category = $category.name
            categoryId = $category.id
            areaPath = $category.areaPath
            timestamp = $timestamp
        } | ConvertTo-Json

    } else {
        Write-Host "Failed to create bug" -ForegroundColor Red
        Write-Host $result -ForegroundColor Red

        @{
            success = $false
            error = "$result"
            title = $Title
            category = $category.name
        } | ConvertTo-Json
    }

} catch {
    Write-Host "Error creating bug: $_" -ForegroundColor Red

    @{
        success = $false
        error = $_.Exception.Message
        title = $Title
    } | ConvertTo-Json
}

# ============================================
# OPTIONAL: LINK TO PARENT WORK ITEM
# ============================================

# Uncomment below to automatically link bugs to parent PBI/Feature
<#
if ($bug -and $category.id) {
    Write-Host "Linking to parent work item #$($category.id)..." -ForegroundColor Yellow

    az boards work-item relation add `
        --id $bug.id `
        --relation-type "Parent" `
        --target-id $category.id `
        --organization $config.organization 2>&1 | Out-Null

    if ($LASTEXITCODE -eq 0) {
        Write-Host "  Linked to parent #$($category.id)" -ForegroundColor Green
    }
}
#>
