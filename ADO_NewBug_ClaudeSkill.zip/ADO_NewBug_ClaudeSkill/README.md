# ADO Bug Filing Skill for Claude Code

File Azure DevOps bugs directly from Claude Code with automatic categorization, formatting, and work item linking.

---

## Features

- **One-Line Bug Filing** - `/newbug title | details | screenshot`
- **Auto-Categorization** - Matches bugs to the right PBI/category based on keywords
- **Smart Formatting** - Generates proper repro steps, expected/actual behavior
- **Area Path Assignment** - Routes bugs to correct team automatically
- **Parent Linking** - Links bugs to parent PBIs or Features
- **Claude Code Native** - Works seamlessly in your terminal workflow

---

## Prerequisites

### 1. Azure CLI

Install Azure CLI:

```powershell
# Windows (winget)
winget install Microsoft.AzureCLI

# Windows (MSI)
# Download from https://aka.ms/installazurecliwindows

# macOS
brew install azure-cli

# Linux
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
```

### 2. Azure DevOps Extension

```bash
az extension add --name azure-devops
```

### 3. Authentication

**Option A: Personal Access Token (Recommended)**

1. Go to Azure DevOps → User Settings → Personal Access Tokens
2. Create token with **Work Items: Read & Write** scope
3. Set environment variable:

```powershell
# Windows
$env:AZURE_DEVOPS_EXT_PAT = "your-pat-token"

# Or set permanently
[Environment]::SetEnvironmentVariable("AZURE_DEVOPS_EXT_PAT", "your-pat-token", "User")
```

```bash
# Linux/macOS
export AZURE_DEVOPS_EXT_PAT="your-pat-token"
```

**Option B: Azure AD Login**

```bash
az login
az devops configure --defaults organization=https://dev.azure.com/your-org project=YourProject
```

### 4. Verify Setup

```bash
# Test connection
az devops project list --organization https://dev.azure.com/your-org

# Test work item access
az boards work-item show --id 12345 --organization https://dev.azure.com/your-org --project YourProject
```

---

## Installation

### Step 1: Copy Files

Copy these files to your Claude Code project:

```
your-project/
├── .claude/
│   └── commands/
│       └── newbug.md          # Skill definition
├── scripts/
│   ├── create_bug.ps1         # PowerShell script
│   └── config.json            # Your ADO configuration
```

### Step 2: Configure Your ADO Settings

Edit `scripts/config.json`:

```json
{
  "organization": "https://dev.azure.com/your-org",
  "project": "YourProject",
  "defaultAreaPath": "YourProject\\YourTeam",
  "defaultIterationPath": "YourProject\\Current Sprint",
  "parentFeatureId": "12345",
  "categories": [
    {
      "id": "11111",
      "name": "Frontend Bugs",
      "keywords": ["button", "UI", "layout", "display", "CSS", "responsive"],
      "areaPath": "YourProject\\YourTeam\\Frontend"
    },
    {
      "id": "22222",
      "name": "Backend Bugs",
      "keywords": ["API", "endpoint", "server", "database", "500", "timeout"],
      "areaPath": "YourProject\\YourTeam\\Backend"
    },
    {
      "id": "33333",
      "name": "Performance Bugs",
      "keywords": ["slow", "latency", "memory", "CPU", "performance"],
      "areaPath": "YourProject\\YourTeam\\Performance"
    },
    {
      "id": "44444",
      "name": "General Bugs",
      "keywords": [],
      "areaPath": "YourProject\\YourTeam"
    }
  ]
}
```

### Step 3: Create the Claude Code Skill

Create `.claude/commands/newbug.md`:

```markdown
# /newbug

File a bug in Azure DevOps.

## Usage
`/newbug <title> | <details> | <image_path>`

## Instructions

1. Parse arguments separated by `|`:
   - First: Bug title (required)
   - Second: Bug details (optional)
   - Third: Image path (optional)

2. Load config from `scripts/config.json`

3. Analyze the bug and determine category:
   - Match keywords in title/details against category keywords
   - Select best matching category
   - Default to "General Bugs" if no match

4. Execute PowerShell script:
   ```powershell
   powershell -File "scripts/create_bug.ps1" `
     -Title "Bug Title" `
     -Description "Description with repro steps" `
     -CategoryId "11111"
   ```

5. Return the bug URL to user

6. Remind user to attach image if provided
```

### Step 4: Create the PowerShell Script

Create `scripts/create_bug.ps1`:

```powershell
param(
    [Parameter(Mandatory=$true)]
    [string]$Title,

    [Parameter(Mandatory=$false)]
    [string]$Description = "",

    [Parameter(Mandatory=$false)]
    [string]$CategoryId = ""
)

# Load configuration
$configPath = Join-Path $PSScriptRoot "config.json"
$config = Get-Content $configPath | ConvertFrom-Json

# Find category
$category = $config.categories | Where-Object { $_.id -eq $CategoryId } | Select-Object -First 1
if (-not $category) {
    $category = $config.categories | Select-Object -Last 1  # Default category
}

# Build description
$fullDescription = @"
## Description
$Description

## Repro Steps
1. [Add step 1]
2. [Add step 2]
3. Observe the issue

## Expected Behavior
[What should happen]

## Actual Behavior
[What actually happens]

## Environment
- Date Reported: $(Get-Date -Format "yyyy-MM-dd")
- Reporter: Filed via Claude Code

## Parent Work Item
Category: $($category.name) (#$($category.id))
"@

# Create the bug
$result = az boards work-item create `
    --title $Title `
    --type "Bug" `
    --description $fullDescription `
    --area $category.areaPath `
    --organization $config.organization `
    --project $config.project `
    --output json 2>&1

if ($LASTEXITCODE -eq 0) {
    $bug = $result | ConvertFrom-Json
    $bugUrl = "$($config.organization)/$($config.project)/_workitems/edit/$($bug.id)"

    # Output JSON result
    @{
        success = $true
        id = $bug.id
        url = $bugUrl
        title = $Title
        category = $category.name
        areaPath = $category.areaPath
    } | ConvertTo-Json
} else {
    @{
        success = $false
        error = $result
    } | ConvertTo-Json
}
```

---

## Usage with Claude Code

### Basic Bug

```
/newbug Submit button doesn't work
```

### Bug with Details

```
/newbug Submit button doesn't work | Clicking submit on the contact form does nothing. No console errors. Tested in Chrome 120.
```

### Bug with Screenshot

```
/newbug Submit button doesn't work | Form submission fails silently | C:\screenshots\form_bug.png
```

### Natural Language (Claude Interprets)

You can also just describe the bug naturally:

```
Hey Claude, the submit button on the contact form isn't working.
Can you file a bug for that? I have a screenshot at C:\bugs\submit.png
```

Claude will use the `/newbug` skill automatically.

---

## Customization

### Adding Categories

Edit `config.json` to add more categories:

```json
{
  "id": "55555",
  "name": "Security Issues",
  "keywords": ["auth", "login", "permission", "access", "token", "XSS", "injection"],
  "areaPath": "YourProject\\Security"
}
```

### Custom Fields

Modify `create_bug.ps1` to add custom fields:

```powershell
# Add priority
--fields "Microsoft.VSTS.Common.Priority=2"

# Add tags
--fields "System.Tags=bug;from-claude"

# Add custom field
--fields "Custom.ReportedBy=Claude Code"
```

### Link to Parent Work Item

Add parent linking in the script:

```powershell
# After creating bug, link to parent
az boards work-item relation add `
    --id $bug.id `
    --relation-type "Parent" `
    --target-id $CategoryId `
    --organization $config.organization
```

---

## Troubleshooting

### "az: command not found"

Azure CLI not installed or not in PATH. Reinstall and restart terminal.

### "Authentication failed"

```bash
# Re-authenticate
az login
az devops configure --defaults organization=https://dev.azure.com/your-org
```

Or check your PAT token:
```powershell
$env:AZURE_DEVOPS_EXT_PAT = "your-new-pat-token"
```

### "Project not found"

Verify project name matches exactly (case-sensitive):
```bash
az devops project list --organization https://dev.azure.com/your-org
```

### "Area path not found"

List valid area paths:
```bash
az boards area project list --organization https://dev.azure.com/your-org --project YourProject
```

### Script Execution Policy (Windows)

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

---

## File Structure

```
your-project/
├── .claude/
│   └── commands/
│       └── newbug.md              # Claude Code skill definition
├── scripts/
│   ├── create_bug.ps1             # Bug creation script
│   └── config.json                # ADO configuration
└── README.md                      # This file
```

---

## Example Workflow

1. **Find a bug while coding:**
   ```
   Hmm, the API is returning 500 errors on large payloads
   ```

2. **File it instantly:**
   ```
   /newbug API returns 500 on large payloads | POST /api/upload fails with 500 when payload > 10MB. Works fine under 5MB.
   ```

3. **Claude creates the bug:**
   ```
   ✅ Bug Created Successfully!

   🔗 https://dev.azure.com/your-org/YourProject/_workitems/edit/98765

   📋 Assigned to: Backend Bugs (#22222)
   📍 Area Path: YourProject\YourTeam\Backend
   ```

4. **Continue coding** - no context switch needed!

---

## Tips

1. **Be descriptive** - More details = better auto-categorization
2. **Include repro steps** - Even brief ones help
3. **Attach screenshots** - Visual bugs need visual evidence
4. **Use consistent keywords** - Helps matching work better
5. **Review config.json** - Keep categories aligned with your ADO structure

---

## License

MIT License - Free to use, modify, and distribute.

---

## Contributing

Feel free to submit issues and pull requests to improve this skill.

---

**Happy bug hunting!** 🐛
